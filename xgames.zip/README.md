xgames
======

This is a game theory package that places emphasis on user-friendly input and coloring each player's name, actions, and payoffs in a dedicated color for ease of distinction.

Installation
------------
Place the xgames.sty and the fikz.sty files in a local TEXMF directory that can be accessed by your Latex distribution.

License
-------
This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License (https://creativecommons.org/licenses/by-sa/4.0/).